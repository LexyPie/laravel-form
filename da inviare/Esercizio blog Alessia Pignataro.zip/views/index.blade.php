@extends('layouts.template')

@section('title','Homepage somme')

@section('content')
    <h1 class="">Benvenuti nel mio sito di somme</h1>
@endsection