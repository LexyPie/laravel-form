@extends('layouts.template')

@section('title','Result')

@section('content')
    <h1>Il risultato della somma è {{$somma}}</h1>
@endsection