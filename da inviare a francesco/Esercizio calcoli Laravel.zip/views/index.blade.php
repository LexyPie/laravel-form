@extends('layouts.template')

@section('title','Homepage Calcoli')

@section('content')
    <h1 class="">Benvenuti nel mio sito di calcoli</h1>
@endsection